Common code used by more than one app, but not by the kernel.
