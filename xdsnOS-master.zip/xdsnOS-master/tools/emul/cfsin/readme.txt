The contents of this folder ends up in the emulated shell's fake block device,
mounted as a CFS. The goal of the emulated shell being to tests apps, we compile
all apps into this folder for use in the emulated shell.
